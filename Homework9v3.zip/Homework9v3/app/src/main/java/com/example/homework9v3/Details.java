package com.example.homework9v3;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;

import org.json.JSONException;
import org.json.JSONObject;

public class Details extends AppCompatActivity {

    private TabLayout tabLayout;
    private ViewPager viewPager;
    private TextView cityName;
    private String location;
    private String response;

    private ProgressBar progressBar;
    private TextView progressBarIndicator;

    @SuppressLint({"SetTextI18n", "SetJavaScriptEnabled"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        progressBar = findViewById(R.id.detail_progress_bar);
        viewPager = findViewById(R.id.view_pager);
        tabLayout = findViewById(R.id.detail_tabs);
        progressBarIndicator = findViewById(R.id.detail_progress_indicator);

        Toolbar toolbar = findViewById(R.id.toolbar_details);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);


        Intent intent = getIntent();
        location = intent.getStringExtra(MainActivity.LOCATION);
        cityName = findViewById(R.id.city_name);
        cityName.setText(location);

        setUpFragments();

    }

    @SuppressLint("StaticFieldLeak")
    public void setUpFragments() {

        new AsyncTask<Void, Void, Void>() {

            protected void onPreExecute() {

                // TODO Auto-generated method stub
                super.onPreExecute();
                progressBar.setVisibility(View.VISIBLE);
                progressBarIndicator.setVisibility(View.VISIBLE);
                tabLayout.setVisibility(View.INVISIBLE);
                viewPager.setVisibility(View.INVISIBLE);

            }

            @SuppressLint("WrongThread")
            @Override
            protected Void doInBackground(Void... voids) {

                try {

                    Thread.sleep(3500);
                    progressBar.setVisibility(View.VISIBLE);
                    progressBarIndicator.setVisibility(View.VISIBLE);
                    tabLayout.setVisibility(View.INVISIBLE);
                    viewPager.setVisibility(View.INVISIBLE);

                } catch (InterruptedException e) {

                    e.printStackTrace();

                }

                Intent intent = getIntent();
                response = intent.getStringExtra(MainActivity.EXTRA_MESSAGE);
                location = intent.getStringExtra(MainActivity.LOCATION);
                String cityPhotos = intent.getStringExtra(MainActivity.CITY_JSON);

                Bundle bundle = new Bundle();
                bundle.putString("response", response);

                Bundle b = new Bundle();
                b.putString("cityJSON", cityPhotos);

                TodayFragment todayFragment = new TodayFragment();
                todayFragment.setArguments(bundle);

                WeeklyFragment weeklyFragment = new WeeklyFragment();
                weeklyFragment.setArguments(bundle);

                PhotosFragment photosFragment = new PhotosFragment();
                photosFragment.setArguments(b);

                final int[] tabIcons = {

                        R.xml.calendar_today,
                        R.xml.trending_up,
                        R.xml.google_photos

                };

                tabLayout = findViewById(R.id.detail_tabs);
                viewPager = findViewById(R.id.view_pager);

                final ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager(), 0);
                adapter.addFragment(todayFragment, "Today");
                adapter.addFragment(weeklyFragment, "Weekly");
                adapter.addFragment(photosFragment, "Photos");

                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {

                        // Stuff that updates the UI
                        viewPager.setAdapter(adapter);
                        tabLayout.setupWithViewPager(viewPager);
                        tabLayout.getTabAt(0).setIcon(tabIcons[0]);
                        tabLayout.getTabAt(1).setIcon(tabIcons[1]);
                        tabLayout.getTabAt(2).setIcon(tabIcons[2]);

                        tabLayout.getTabAt(0).getIcon().setColorFilter(getResources().getColor(android.R.color.white), PorterDuff.Mode.SRC_IN);
                        tabLayout.getTabAt(1).getIcon().setColorFilter(getResources().getColor(R.color.gray), PorterDuff.Mode.SRC_IN);
                        tabLayout.getTabAt(2).getIcon().setColorFilter(getResources().getColor(R.color.gray), PorterDuff.Mode.SRC_IN);

                        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {

                            @Override
                            public void onTabSelected(TabLayout.Tab tab) {

                                tab.getIcon().setColorFilter(getResources().getColor(android.R.color.white), PorterDuff.Mode.SRC_IN);

                            }

                            @Override
                            public void onTabUnselected(TabLayout.Tab tab) {

                                tab.getIcon().setColorFilter(getResources().getColor(R.color.gray), PorterDuff.Mode.SRC_IN);

                            }

                            @Override
                            public void onTabReselected(TabLayout.Tab tab) {

                            }
                        });

                    }
                });
                return null;

            }

            protected void onPostExecute(Void result) {

                progressBar.setVisibility(View.GONE);
                progressBarIndicator.setVisibility(View.GONE);
                tabLayout.setVisibility(View.VISIBLE);
                viewPager.setVisibility(View.VISIBLE);

            }
        }.execute();

    }

    public void openTwitterIntent(View view) throws JSONException {

        JSONObject resp = new JSONObject(response);
        int temp = resp.getJSONObject("currently").getInt("temperature");
        String tweet = "Check out " + location + "'s Weather! It is " + temp + "°F!" ;
        String tweetUrl = "https://twitter.com/intent/tweet?text=" + tweet + "&hashtags=CSCI571WeatherSearch";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(tweetUrl));
        startActivity(intent);


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();
        if(id == android.R.id.home) {
            this.finish();
        }
        return super.onOptionsItemSelected(item);

    }
}
