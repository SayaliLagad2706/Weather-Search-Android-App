package com.example.homework9v3;

import android.annotation.SuppressLint;
import android.app.SearchManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.SearchRecentSuggestions;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SearchableActivity extends AppCompatActivity {

    public static final String JARGON = "com.example.searchinterface.jargon";
    public static final String CURRENTLY = "currently";
    public static final String FLAG = "flag";
    public static final String LOCATION = "location";

    public static final String EXTRA_MESSAGE = "response";
    public static final String CITY_JSON = "cityPhotos";
    public boolean fromSearchable = false;

    private TextView location;
    private RequestQueue queue;
    private ImageView icon;
    private TextView temperature;
    private TextView summary;
    private TextView humidity;
    private TextView windSpeed;
    private TextView visibility;
    private TextView pressure;
    private TextView tableDate;
    private ImageView tableIcon;
    private TextView tableTempLow;
    private TextView tableTempHigh;

    private FloatingActionButton favButton;
    private boolean flag = false;
    private String addr;
    private CardView overView;
    private CardView properties;
    private CardView details;
    private ScrollView scrollView;
    private TextView progressBarIndicator;

    private JSONObject currently;
    private String query = "";

    private JSONObject resp = new JSONObject();
    private SharedPreferences.Editor editor;
    private JSONObject cityPhotosJson;
    private ProgressBar progressBar;

    @SuppressLint("CommitPrefEdits")
    @Override
    protected void onCreate(Bundle savedInstanceState){

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);

        editor = sharedPreferences.edit();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.search);

        progressBar = findViewById(R.id.search_progress_bar);
        overView = findViewById(R.id.overview_card);
        properties = findViewById(R.id.properties_card);
        details = findViewById(R.id.detail_card);
        scrollView = findViewById(R.id.scrollView4);
        progressBarIndicator = findViewById(R.id.search_progress_indicator);

        progressBar.setVisibility(View.VISIBLE);
        progressBarIndicator.setVisibility(View.VISIBLE);
        properties.setVisibility(View.INVISIBLE);
        overView.setVisibility(View.INVISIBLE);
        details.setVisibility(View.INVISIBLE);
        scrollView.setVisibility(View.INVISIBLE);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        favButton = findViewById(R.id.Add_fav);
        favButton.setImageResource(R.drawable.remove_fav);

        // Get the intent, verify the action and get the query
        Intent intent = getIntent();
        if (Intent.ACTION_SEARCH.equals(intent.getAction())) {

            query = intent.getStringExtra(SearchManager.QUERY);
            addr = query;
            assert query != null;
            doMySearch(query);
            TextView selectedCity = findViewById(R.id.Selected_city);
            selectedCity.setText(query);
            SearchRecentSuggestions suggestions = new SearchRecentSuggestions(this,
                    MySuggestionProvider.AUTHORITY, MySuggestionProvider.MODE);
            suggestions.saveRecentQuery(query, null);

        }

        if(sharedPreferences.getAll().containsKey(query)) {

            flag = true;
            favButton.setImageResource(R.drawable.add_fav);

        }

    }

    public void checkFavorites(View view) {

        fromSearchable = true;
        if(flag) {

            Toast toast = Toast.makeText(SearchableActivity.this, addr + " was removed from favorites", Toast.LENGTH_LONG);
            View toastView = toast.getView();
            toastView.setBackgroundColor(getResources().getColor(R.color.colorAccent));
            toastView.setPadding(30, 30,30,30);
            TextView textView = toast.getView().findViewById(android.R.id.message);
            textView.setTextColor(getResources().getColor(R.color.darkGray));
            toast.show();

            flag = false;
            editor.remove(addr);
            editor.commit();
            favButton.setImageResource(R.drawable.remove_fav);

        }
        else {

            Toast toast = Toast.makeText(SearchableActivity.this, addr + " was added to favorites", Toast.LENGTH_LONG);
            View toastView = toast.getView();
            toastView.setBackgroundColor(getResources().getColor(R.color.colorAccent));
            toastView.setPadding(30, 30,30,30);
            TextView textView = toast.getView().findViewById(android.R.id.message);
            textView.setTextColor(getResources().getColor(R.color.darkGray));
            toast.show();

            flag = true;
            editor.putString(addr, addr);
            editor.commit();
            favButton.setImageResource(R.drawable.add_fav);

        }
    }

    @SuppressLint("StaticFieldLeak")
    public void doMySearch(String query) {

        queue = Volley.newRequestQueue(this);
        final String s = query;

        new AsyncTask<Void, Void, Void>() {

            protected void onPreExecute() {

                // TODO Auto-generated method stub
                super.onPreExecute();
                progressBar.setVisibility(View.VISIBLE);
                progressBarIndicator.setVisibility(View.VISIBLE);
                properties.setVisibility(View.INVISIBLE);
                overView.setVisibility(View.INVISIBLE);
                details.setVisibility(View.INVISIBLE);
                scrollView.setVisibility(View.INVISIBLE);

            }

            @SuppressLint("WrongThread")
            @Override
            protected Void doInBackground(Void... voids) {

                try {

                    Thread.sleep(3500);
                    progressBar.setVisibility(View.VISIBLE);
                    progressBarIndicator.setVisibility(View.VISIBLE);
                    properties.setVisibility(View.INVISIBLE);
                    overView.setVisibility(View.INVISIBLE);
                    details.setVisibility(View.INVISIBLE);
                    scrollView.setVisibility(View.INVISIBLE);

                } catch (InterruptedException e) {

                    e.printStackTrace();

                }

                location = findViewById(R.id.location);
                icon = findViewById(R.id.icon);
                temperature = findViewById(R.id.temperature);
                summary = findViewById(R.id.summary);
                humidity = findViewById(R.id.humidity_value);
                windSpeed = findViewById(R.id.wind_speed_value);
                visibility = findViewById(R.id.visibility_value);
                pressure = findViewById(R.id.pressure_value);

                final String address = s.replace(" ", "%20");
                final String url = "http://localhost:8081/weatherCard?address=" + address;
                final String cityUrl = "http://localhost:8081/getCityImages?city=" + address;

                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {

                        // Stuff that updates the UI
                        location.setText(s);

                JsonObjectRequest req = new JsonObjectRequest(Request.Method.GET, url, null,
                        new Response.Listener<JSONObject>() {

                            @SuppressLint("SetTextI18n")
                            @Override
                            public void onResponse(JSONObject response) {

                                try {

                                    resp = response;
                                    currently = response.getJSONObject("currently");

                                    JSONObject daily = response.getJSONObject("daily");
                                    JSONArray data = daily.getJSONArray("data");

                                    temperature.setText((int)(currently.getDouble("temperature")) + "°F");
                                    summary.setText(currently.getString("summary"));
                                    humidity.setText((int)((currently.getDouble("humidity")*100)) + "%");
                                    windSpeed.setText(Math.round(currently.getDouble("windSpeed")*100.0)/100.0 + " mph");
                                    visibility.setText(Math.round(currently.getDouble("visibility")*100.0)/100.0 + " km");
                                    pressure.setText(Math.round(currently.getDouble("pressure")*100.0)/100.0 + " mb");

                                    for(int i = 0; i < 8; i++) {

                                        JSONObject table = data.getJSONObject(i);
                                        String idDate = "day_" + (i+1);
                                        String idIcon = "icon_day_" + (i+1);
                                        String idTempLow = "temp_low_" + (i+1);
                                        String idTempHigh = "temp_high_" + (i+1);

                                        int dateId = getResources().getIdentifier(idDate, "id", getPackageName());
                                        int iconId = getResources().getIdentifier(idIcon, "id", getPackageName());
                                        int tempLowId = getResources().getIdentifier(idTempLow, "id", getPackageName());
                                        int tempHighId = getResources().getIdentifier(idTempHigh, "id", getPackageName());
                                        tableDate = findViewById(dateId);
                                        long t = table.getLong("time");

                                        Date date = new Date(t*1000);
                                        @SuppressLint("SimpleDateFormat") SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

                                        tableDate.setText(sdf.format(date) + "");
                                        tableIcon = findViewById(iconId);
                                        switch(table.getString("icon")) {

                                            case "clear-night":
                                                tableIcon.setImageResource(R.drawable.weather_night);
                                                break;

                                            case "rain":
                                                tableIcon.setImageResource(R.drawable.weather_rainy);
                                                break;

                                            case "sleet":
                                                tableIcon.setImageResource(R.drawable.weather_snowy_rainy);
                                                break;

                                            case "snow":
                                                tableIcon.setImageResource(R.drawable.weather_snowy);
                                                break;

                                            case "wind":
                                                tableIcon.setImageResource(R.drawable.weather_windy_variant);
                                                break;

                                            case "fog":
                                                tableIcon.setImageResource(R.drawable.weather_fog);
                                                break;

                                            case "cloudy":
                                                tableIcon.setImageResource(R.drawable.weather_cloudy);
                                                break;

                                            case "partly-cloudy-night":
                                                tableIcon.setImageResource(R.drawable.weather_night_partly_cloudy);
                                                break;

                                            case "partly-cloudy-day":
                                                tableIcon.setImageResource(R.drawable.weather_partly_cloudy);
                                                break;

                                            default:
                                                tableIcon.setImageResource(R.drawable.weather_sunny);
                                                break;
                                        }

                                        tableTempLow = findViewById(tempLowId);
                                        tableTempLow.setText((int)(table.getDouble("temperatureLow")) + "");
                                        tableTempHigh = findViewById(tempHighId);
                                        tableTempHigh.setText((int)(table.getDouble("temperatureHigh")) + "");
                                    }

                                    switch(currently.getString("icon")) {

                                        case "clear-night":
                                            icon.setImageResource(R.drawable.weather_night);
                                            break;

                                        case "rain":
                                            icon.setImageResource(R.drawable.weather_rainy);
                                            break;

                                        case "sleet":
                                            icon.setImageResource(R.drawable.weather_snowy_rainy);
                                            break;

                                        case "snow":
                                            icon.setImageResource(R.drawable.weather_snowy);
                                            break;

                                        case "wind":
                                            icon.setImageResource(R.drawable.weather_windy_variant);
                                            break;

                                        case "fog":
                                            icon.setImageResource(R.drawable.weather_fog);
                                            break;

                                        case "cloudy":
                                            icon.setImageResource(R.drawable.weather_cloudy);
                                            break;

                                        case "partly-cloudy-night":
                                            icon.setImageResource(R.drawable.weather_night_partly_cloudy);
                                            break;

                                        case "partly-cloudy-day":
                                            icon.setImageResource(R.drawable.weather_partly_cloudy);
                                            break;

                                        default:
                                            icon.setImageResource(R.drawable.weather_sunny);
                                            break;
                                    }
                                } catch (JSONException e) {

                                    e.printStackTrace();

                                }
                            }
                        }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {

                        error.printStackTrace();

                    }
                });
                queue.add(req);
                JsonObjectRequest cityReq = new JsonObjectRequest(Request.Method.GET, cityUrl, null,
                        new Response.Listener<JSONObject>() {

                    @SuppressLint("SetTextI18n")
                    @Override
                    public void onResponse(JSONObject response) {

                        cityPhotosJson = response;

                    }

                    }, new Response.ErrorListener() {

                                @Override
                                public void onErrorResponse(VolleyError error) {

                                    error.printStackTrace();

                                }
                            });
                            queue.add(cityReq);
                    }
                });
                return null;
            }

            protected void onPostExecute(Void result) {

                progressBar.setVisibility(View.GONE);
                progressBarIndicator.setVisibility(View.GONE);
                properties.setVisibility(View.VISIBLE);
                overView.setVisibility(View.VISIBLE);
                details.setVisibility(View.VISIBLE);
                scrollView.setVisibility(View.VISIBLE);

            }
        }.execute();
    }

    public void openDetailsActivity(View view) {

        Intent intent = new Intent(this, Details.class);
        intent.putExtra(EXTRA_MESSAGE, resp + "");
        intent.putExtra(LOCATION, addr);
        intent.putExtra(CITY_JSON, cityPhotosJson + "");
        startActivity(intent);

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if(id == android.R.id.home) {

            this.finish();
            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra(CURRENTLY, resp + "");
            intent.putExtra(LOCATION, addr);
            intent.putExtra(FLAG, flag + "");
            startActivity(intent);

        }
        return super.onOptionsItemSelected(item);
    }
}
