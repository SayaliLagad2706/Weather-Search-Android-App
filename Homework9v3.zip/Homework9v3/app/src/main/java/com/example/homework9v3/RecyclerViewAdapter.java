package com.example.homework9v3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {

    private Context context;
    private List<String> data;

    RecyclerViewAdapter(Context context, List<String> data) {

        this.context = context;
        this.data = data;

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v;
        v = LayoutInflater.from(context).inflate(R.layout.recycler_view_element, parent, false);
        return new ViewHolder(v);

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Glide.with(context).load(data.get(position)).into(holder.img);

    }

    @Override
    public int getItemCount() {

        return data.size();

    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        private ImageView img;

        ViewHolder(@NonNull View itemView) {

            super(itemView);
            img = itemView.findViewById(R.id.photo);

        }
    }
}
