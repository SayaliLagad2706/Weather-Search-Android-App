package com.example.homework9v3;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewpager.widget.PagerAdapter;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class SlideAdapter extends PagerAdapter {

    private Context context;
    private boolean doNotifyDataSetChangedOnce = false;

    ArrayList<String> lstOfLocations = new ArrayList<>();
    ArrayList<Integer> lstOfIcons = new ArrayList<>();
    ArrayList<String> lstOfTemperature = new ArrayList<>();
    ArrayList<String> lstOfSummary = new ArrayList<>();
    ArrayList<String> lstOfHumidityVals = new ArrayList<>();
    ArrayList<String> lstOfWindSpeedVals = new ArrayList<>();
    ArrayList<String> lstOfVisibilityVals = new ArrayList<>();
    ArrayList<String> lstOfPressureVals = new ArrayList<>();

    ArrayList<String> lstOfDay1Dates = new ArrayList<>();
    ArrayList<String> lstOfDay2Dates = new ArrayList<>();
    ArrayList<String> lstOfDay3Dates = new ArrayList<>();
    ArrayList<String> lstOfDay4Dates = new ArrayList<>();
    ArrayList<String> lstOfDay5Dates = new ArrayList<>();
    ArrayList<String> lstOfDay6Dates = new ArrayList<>();
    ArrayList<String> lstOfDay7Dates = new ArrayList<>();
    ArrayList<String> lstOfDay8Dates = new ArrayList<>();

    ArrayList<Integer> lstOfDay1Icons = new ArrayList<>();
    ArrayList<Integer> lstOfDay2Icons = new ArrayList<>();
    ArrayList<Integer> lstOfDay3Icons = new ArrayList<>();
    ArrayList<Integer> lstOfDay4Icons = new ArrayList<>();
    ArrayList<Integer> lstOfDay5Icons = new ArrayList<>();
    ArrayList<Integer> lstOfDay6Icons = new ArrayList<>();
    ArrayList<Integer> lstOfDay7Icons = new ArrayList<>();
    ArrayList<Integer> lstOfDay8Icons = new ArrayList<>();

    ArrayList<String> lstOfDay1TempLow = new ArrayList<>();
    ArrayList<String> lstOfDay2TempLow = new ArrayList<>();
    ArrayList<String> lstOfDay3TempLow = new ArrayList<>();
    ArrayList<String> lstOfDay4TempLow = new ArrayList<>();
    ArrayList<String> lstOfDay5TempLow = new ArrayList<>();
    ArrayList<String> lstOfDay6TempLow = new ArrayList<>();
    ArrayList<String> lstOfDay7TempLow = new ArrayList<>();
    ArrayList<String> lstOfDay8TempLow = new ArrayList<>();

    ArrayList<String> lstOfDay1TempHigh = new ArrayList<>();
    ArrayList<String> lstOfDay2TempHigh = new ArrayList<>();
    ArrayList<String> lstOfDay3TempHigh = new ArrayList<>();
    ArrayList<String> lstOfDay4TempHigh = new ArrayList<>();
    ArrayList<String> lstOfDay5TempHigh = new ArrayList<>();
    ArrayList<String> lstOfDay6TempHigh = new ArrayList<>();
    ArrayList<String> lstOfDay7TempHigh = new ArrayList<>();
    ArrayList<String> lstOfDay8TempHigh = new ArrayList<>();

    @Override
    public int getCount() {

        if (doNotifyDataSetChangedOnce) {
            doNotifyDataSetChangedOnce = false;
            notifyDataSetChanged();
        }
        return lstOfLocations.size();

    }

    SlideAdapter(Context context) {

        this.context = context;

    }

    @SuppressLint("RestrictedApi")
    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {

        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.slide, container, false);
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);

        FloatingActionButton floatingActionButton  = view.findViewById(R.id.Add_fav);

        ImageView icon = view.findViewById(R.id.icon);
        TextView temperature = view.findViewById(R.id.temperature);
        TextView summary = view.findViewById(R.id.summary);
        TextView location = view.findViewById(R.id.location);

        TextView humidityVal = view.findViewById(R.id.humidity_value);
        TextView windSpeedVal = view.findViewById(R.id.wind_speed_value);
        TextView visibilityVal = view.findViewById(R.id.visibility_value);
        TextView pressureVal = view.findViewById(R.id.pressure_value);

        TextView day1 = view.findViewById(R.id.day_1);
        TextView day2 = view.findViewById(R.id.day_2);
        TextView day3 = view.findViewById(R.id.day_3);
        TextView day4 = view.findViewById(R.id.day_4);
        TextView day5 = view.findViewById(R.id.day_5);
        TextView day6 = view.findViewById(R.id.day_6);
        TextView day7 = view.findViewById(R.id.day_7);
        TextView day8 = view.findViewById(R.id.day_8);

        ImageView iconDay1 = view.findViewById(R.id.icon_day_1);
        ImageView iconDay2 = view.findViewById(R.id.icon_day_2);
        ImageView iconDay3 = view.findViewById(R.id.icon_day_3);
        ImageView iconDay4 = view.findViewById(R.id.icon_day_4);
        ImageView iconDay5 = view.findViewById(R.id.icon_day_5);
        ImageView iconDay6 = view.findViewById(R.id.icon_day_6);
        ImageView iconDay7 = view.findViewById(R.id.icon_day_7);
        ImageView iconDay8 = view.findViewById(R.id.icon_day_8);

        TextView tempLow1 = view.findViewById(R.id.temp_low_1);
        TextView tempLow2 = view.findViewById(R.id.temp_low_2);
        TextView tempLow3 = view.findViewById(R.id.temp_low_3);
        TextView tempLow4 = view.findViewById(R.id.temp_low_4);
        TextView tempLow5 = view.findViewById(R.id.temp_low_5);
        TextView tempLow6 = view.findViewById(R.id.temp_low_6);
        TextView tempLow7 = view.findViewById(R.id.temp_low_7);
        TextView tempLow8 = view.findViewById(R.id.temp_low_8);

        TextView tempHigh1 = view.findViewById(R.id.temp_high_1);
        TextView tempHigh2 = view.findViewById(R.id.temp_high_2);
        TextView tempHigh3 = view.findViewById(R.id.temp_high_3);
        TextView tempHigh4 = view.findViewById(R.id.temp_high_4);
        TextView tempHigh5 = view.findViewById(R.id.temp_high_5);
        TextView tempHigh6 = view.findViewById(R.id.temp_high_6);
        TextView tempHigh7 = view.findViewById(R.id.temp_high_7);
        TextView tempHigh8 = view.findViewById(R.id.temp_high_8);

        if(sharedPreferences.getAll().containsKey(lstOfLocations.get(position))) {

            floatingActionButton.setVisibility(View.VISIBLE);

        }

        icon.setImageResource(lstOfIcons.get(position));
        temperature.setText(lstOfTemperature.get(position));
        summary.setText(lstOfSummary.get(position));
        location.setText(lstOfLocations.get(position));

        humidityVal.setText(lstOfHumidityVals.get(position));
        pressureVal.setText(lstOfPressureVals.get(position));
        visibilityVal.setText(lstOfVisibilityVals.get(position));
        windSpeedVal.setText(lstOfWindSpeedVals.get(position));

        day1.setText(lstOfDay1Dates.get(position));
        day2.setText(lstOfDay2Dates.get(position));
        day3.setText(lstOfDay3Dates.get(position));
        day4.setText(lstOfDay4Dates.get(position));
        day5.setText(lstOfDay5Dates.get(position));
        day6.setText(lstOfDay6Dates.get(position));
        day7.setText(lstOfDay7Dates.get(position));
        day8.setText(lstOfDay8Dates.get(position));

        iconDay1.setImageResource(lstOfDay1Icons.get(position));
        iconDay2.setImageResource(lstOfDay2Icons.get(position));
        iconDay3.setImageResource(lstOfDay3Icons.get(position));
        iconDay4.setImageResource(lstOfDay4Icons.get(position));
        iconDay5.setImageResource(lstOfDay5Icons.get(position));
        iconDay6.setImageResource(lstOfDay6Icons.get(position));
        iconDay7.setImageResource(lstOfDay7Icons.get(position));
        iconDay8.setImageResource(lstOfDay8Icons.get(position));

        tempLow1.setText(lstOfDay1TempLow.get(position));
        tempLow2.setText(lstOfDay2TempLow.get(position));
        tempLow3.setText(lstOfDay3TempLow.get(position));
        tempLow4.setText(lstOfDay4TempLow.get(position));
        tempLow5.setText(lstOfDay5TempLow.get(position));
        tempLow6.setText(lstOfDay6TempLow.get(position));
        tempLow7.setText(lstOfDay7TempLow.get(position));
        tempLow8.setText(lstOfDay8TempLow.get(position));

        tempHigh1.setText(lstOfDay1TempHigh.get(position));
        tempHigh2.setText(lstOfDay2TempHigh.get(position));
        tempHigh3.setText(lstOfDay3TempHigh.get(position));
        tempHigh4.setText(lstOfDay4TempHigh.get(position));
        tempHigh5.setText(lstOfDay5TempHigh.get(position));
        tempHigh6.setText(lstOfDay6TempHigh.get(position));
        tempHigh7.setText(lstOfDay7TempHigh.get(position));
        tempHigh8.setText(lstOfDay8TempHigh.get(position));

        container.addView(view);

        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {

        container.removeView((ConstraintLayout)object);

    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {

        return (view==(ConstraintLayout)object);

    }
}

