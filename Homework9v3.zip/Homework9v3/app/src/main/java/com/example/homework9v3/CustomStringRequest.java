package com.example.homework9v3;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

public class CustomStringRequest extends StringRequest {

    private Priority priority = Priority.LOW;

    public CustomStringRequest(int method, String url, Response.Listener<String> listener, Response.ErrorListener errorListener) {

        super(method, url, listener, errorListener);

    }

    @Override
    public Priority getPriority() {

        return priority;

    }

    public void setPriority(Priority priority) {

        this.priority = priority;

    }
}
