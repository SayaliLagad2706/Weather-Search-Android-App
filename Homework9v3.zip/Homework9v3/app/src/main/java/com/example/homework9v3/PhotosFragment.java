package com.example.homework9v3;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class PhotosFragment extends Fragment {

    private JSONObject cityPhotosJson;
    private List<String> lstPhotos;

    public PhotosFragment() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.photos, container, false);
        RecyclerView recyclerView = view.findViewById(R.id.city_photos);
        RecyclerViewAdapter recyclerViewAdapter = new RecyclerViewAdapter(getContext(), lstPhotos);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(recyclerViewAdapter);
        return view;

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        lstPhotos = new ArrayList<>();
        JSONArray items = new JSONArray();

        try {

            assert getArguments() != null;
            cityPhotosJson = new JSONObject(getArguments().getString("cityJSON"));

        } catch (JSONException e) {

            e.printStackTrace();

        }

        try {

            items = cityPhotosJson.getJSONArray("items");

        } catch (JSONException e) {

            e.printStackTrace();

        }

        for(int i = 0; i < 8; i++) {

            String url = "";
            try {

                url = items.getJSONObject(i).getString("link");
                lstPhotos.add(url);

            } catch (JSONException e) {

                e.printStackTrace();

            }
        }
    }
}
