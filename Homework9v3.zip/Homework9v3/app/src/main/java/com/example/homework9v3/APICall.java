package com.example.homework9v3;
import android.annotation.SuppressLint;
import android.content.Context;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

class APICall {
    @SuppressLint("StaticFieldLeak")
    private static APICall mInstance;
    private RequestQueue mRequestQueue;
    @SuppressLint("StaticFieldLeak")
    private static Context mCtx;

    private APICall(Context ctx) {

        mCtx = ctx;
        mRequestQueue = getRequestQueue();

    }

    private static synchronized APICall getInstance(Context context) {

        if (mInstance == null) {
            mInstance = new APICall(context);
        }
        return mInstance;

    }

    private RequestQueue getRequestQueue() {

        if (mRequestQueue == null) {
            mRequestQueue = Volley.newRequestQueue(mCtx.getApplicationContext());
        }
        return mRequestQueue;

    }

    private <T> void addToRequestQueue(Request<T> req) {

        getRequestQueue().add(req);

    }

    static void make(Context ctx, String query, Response.Listener<String>
            listener, Response.ErrorListener errorListener) {

        String url = "http://localhost:8081/demo?input=" + query;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                listener, errorListener);
        APICall.getInstance(ctx).addToRequestQueue(stringRequest);

    }
}
