package com.example.homework9v3;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import org.json.JSONException;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class TodayFragment extends Fragment {

    private View view;

    public TodayFragment() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.today, container, false);
        ProgressBar progressBar = view.findViewById(R.id.fragment_progress_bar);
        setData();
        return view;
    }

    @SuppressLint({"StaticFieldLeak", "DefaultLocale", "SetTextI18n"})
    private void setData() {

        String response = getArguments() != null ? getArguments().getString("response") : null;
        JSONObject jsonResp = null;

        try {

            assert response != null;
            jsonResp = new JSONObject(response);

        } catch (JSONException e) {

            e.printStackTrace();

        }

        JSONObject currently = null;
        try {

            assert jsonResp != null;
            currently = jsonResp.getJSONObject("currently");

        } catch (JSONException e) {

            e.printStackTrace();

        }

        TextView windSpeed = view.findViewById(R.id.wind_speed_value);
        TextView pressure = view.findViewById(R.id.pressure_value);
        TextView precipitation = view.findViewById(R.id.precipitation_value);
        TextView temperature = view.findViewById(R.id.temperature_value);
        TextView summary = view.findViewById(R.id.summary_value);
        TextView humidity = view.findViewById(R.id.humidity_value);
        TextView visibility = view.findViewById(R.id.visibility_value);
        TextView cloudCover = view.findViewById(R.id.cloud_cover_value);
        TextView ozone = view.findViewById(R.id.ozone_value);
        ImageView icon = view.findViewById(R.id.summary_icon);

        try {
            assert currently != null;
            windSpeed.setText(String.format("%s mph", round(currently.getDouble("windSpeed"))));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            precipitation.setText(String.format("%s mmph", round(currently.getDouble("precipIntensity"))));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            temperature.setText(String.format("%d°F", currently.getInt("temperature")));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            pressure.setText(round(currently.getDouble("pressure")) + " mb");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            humidity.setText((int)(currently.getDouble("humidity")*100) + "%");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            visibility.setText(round(currently.getDouble("visibility")) + " km");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            cloudCover.setText((int)(currently.getDouble("cloudCover")*100) + "%");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            ozone.setText(round(currently.getDouble("ozone")) + " DU");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {

            summary.setText((currently.getString("icon").replace("-", " ")));

            switch(currently.getString("icon")) {

                case "clear-night":
                    icon.setImageResource(R.drawable.weather_night);
                    break;

                case "rain":
                    icon.setImageResource(R.drawable.weather_rainy);
                    break;

                case "sleet":
                    icon.setImageResource(R.drawable.weather_snowy_rainy);
                    break;

                case "snow":
                    icon.setImageResource(R.drawable.weather_snowy);
                    break;

                case "wind":
                    icon.setImageResource(R.drawable.weather_windy_variant);
                    break;

                case "fog":
                    icon.setImageResource(R.drawable.weather_fog);
                    break;

                case "cloudy":
                    icon.setImageResource(R.drawable.weather_cloudy);
                    break;

                case "partly-cloudy-night":
                    icon.setImageResource(R.drawable.weather_night_partly_cloudy);
                    break;

                case "partly-cloudy-day":
                    icon.setImageResource(R.drawable.weather_partly_cloudy);
                    break;

                default:
                    icon.setImageResource(R.drawable.weather_sunny);
                    break;
            }
        } catch (JSONException e) {

            e.printStackTrace();

        }
    }

    private static double round(double value) {

        BigDecimal bd = BigDecimal.valueOf(value);
        bd = bd.setScale(2, RoundingMode.HALF_UP);
        return bd.doubleValue();

    }
}
