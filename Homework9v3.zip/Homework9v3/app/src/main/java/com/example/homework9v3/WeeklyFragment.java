package com.example.homework9v3;


import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class WeeklyFragment extends Fragment {

    private JSONArray data;

    public WeeklyFragment() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.weekly, container, false);

        LineChart temperatureChart = view.findViewById(R.id.line_chart);

        String response = getArguments() != null ? getArguments().getString("response") : null;
        JSONObject jsonResp = null;
        JSONObject daily = null;

        try {
            assert response != null;
            jsonResp = new JSONObject(response);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            assert jsonResp != null;
            daily = jsonResp.getJSONObject("daily");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            assert daily != null;
            data = daily.getJSONArray("data");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        ImageView weekIcon = view.findViewById(R.id.week_icon);
        TextView weekSummary = view.findViewById(R.id.week_summary);

        try {
            weekSummary.setText(daily.getString("summary"));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {

            String icon = daily.getString("icon");

            switch(icon) {

                case "clear-night":
                    weekIcon.setImageResource(R.drawable.weather_night);
                    break;

                case "rain":
                    weekIcon.setImageResource(R.drawable.weather_rainy);
                    break;

                case "sleet":
                    weekIcon.setImageResource(R.drawable.weather_snowy_rainy);
                    break;

                case "snow":
                    weekIcon.setImageResource(R.drawable.weather_snowy);
                    break;

                case "wind":
                    weekIcon.setImageResource(R.drawable.weather_windy_variant);
                    break;

                case "fog":
                    weekIcon.setImageResource(R.drawable.weather_fog);
                    break;

                case "cloudy":
                    weekIcon.setImageResource(R.drawable.weather_cloudy);
                    break;

                case "partly-cloudy-night":
                    weekIcon.setImageResource(R.drawable.weather_night_partly_cloudy);
                    break;

                case "partly-cloudy-day":
                    weekIcon.setImageResource(R.drawable.weather_partly_cloudy);
                    break;

                default:
                    weekIcon.setImageResource(R.drawable.weather_sunny);
                    break;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        LineDataSet lineDataSetLow = null;
        LineDataSet lineDataSetHigh = null;

        try {
            lineDataSetLow = new LineDataSet(dataValuesLow(), "Minimum Temperature");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            lineDataSetHigh = new LineDataSet(dataValuesHigh(), "Maximum Temperature");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        ArrayList<ILineDataSet> dataSets = new ArrayList<>();
        dataSets.add(lineDataSetLow);
        dataSets.add(lineDataSetHigh);

        assert lineDataSetLow != null;
        lineDataSetLow.setColor(Color.rgb(179, 135, 231));
        assert lineDataSetHigh != null;
        lineDataSetHigh.setColor(Color.rgb(250, 175, 27));

        LineData data = new LineData(dataSets);
        temperatureChart.getAxisLeft().setTextColor(Color.WHITE); // left y-axis
        temperatureChart.getAxisRight().setTextColor(Color.WHITE); // right y-axis
        temperatureChart.getXAxis().setTextColor(Color.WHITE);
        temperatureChart.getLegend().setTextColor(Color.WHITE);
        temperatureChart.getLegend().setTextSize(15f);
        temperatureChart.setData(data);
        temperatureChart.invalidate();

        return view;
    }

    private ArrayList<Entry> dataValuesLow() throws JSONException {

        ArrayList<Entry> dataVals = new ArrayList<>();
        for(int i = 0; i < 8; i++) {
            JSONObject weekValues = data.getJSONObject(i);
            dataVals.add(new Entry(i, weekValues.getInt("temperatureLow")));
        }
        return dataVals;

    }

    private ArrayList<Entry> dataValuesHigh() throws JSONException {

        ArrayList<Entry> dataVals = new ArrayList<>();
        for(int i = 0; i < 8; i++) {
            JSONObject weekValues = data.getJSONObject(i);
            dataVals.add(new Entry(i, weekValues.getInt("temperatureHigh")));
        }
        return dataVals;

    }
}
