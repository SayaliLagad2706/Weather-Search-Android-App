package com.example.homework9v3;

import android.annotation.SuppressLint;
import android.app.SearchManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.view.MenuItemCompat;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.tabs.TabLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity implements SearchView.OnQueryTextListener{

    private ViewPager viewPager;
    private TabLayout linearLayout;
    public SlideAdapter slideAdapter = new SlideAdapter(this);
    private SearchView searchView;

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    public ArrayList<String> dummy = new ArrayList<>();

    public static final String EXTRA_MESSAGE = "response";
    public static final String LOCATION = "location";
    public static final String CITY_JSON = "cityPhotos";
    private JSONObject cityPhotosJson;
    private String loc;
    private RequestQueue queue;
    private static final int TRIGGER_AUTO_COMPLETE = 100;
    private static final long AUTO_COMPLETE_DELAY = 50;
    private Handler handler;
    private AutoSuggestAdapter autoSuggestAdapter;
    private JSONObject resp;

    private String res = "";
    private String flag = "";
    private String address = "";

    private JSONObject r = new JSONObject();
    private JSONObject c = new JSONObject();

    private ProgressBar progressBar;
    private TextView progressBarIndicator;
    private ViewPager viewPagerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        setProgressBarIndeterminateVisibility(true);

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressBar = findViewById(R.id.main_progress_bar);
        progressBar.setVisibility(View.VISIBLE);

        viewPagerLayout = findViewById(R.id.view_pager);
        viewPagerLayout.setVisibility(View.INVISIBLE);

        progressBarIndicator = findViewById(R.id.main_progress_indicator);
        progressBarIndicator.setVisibility(View.VISIBLE);

        queue = Volley.newRequestQueue(this);
        doTasks();

        viewPager = findViewById(R.id.view_pager);
        linearLayout = findViewById(R.id.linear_layout);
        slideAdapter.notifyDataSetChanged();
        viewPager.setAdapter(slideAdapter);
        linearLayout.setupWithViewPager(viewPager, true);

    }

    @SuppressLint("StaticFieldLeak")
    public void doTasks() {

        new AsyncTask<Void, Void, Void>() {

            protected void onPreExecute() {

                // TODO Auto-generated method stub
                super.onPreExecute();
                progressBar.setVisibility(View.VISIBLE);
                progressBarIndicator.setVisibility(View.VISIBLE);

            }

            @SuppressLint("WrongThread")
            @Override
            protected Void doInBackground(Void... voids) {

                try {

                    Thread.sleep(2500);
                    progressBar.setVisibility(View.VISIBLE);
                    progressBarIndicator.setVisibility(View.VISIBLE);
                    viewPagerLayout.setVisibility(View.INVISIBLE);


                } catch (InterruptedException e) {

                    e.printStackTrace();

                }

                publishProgress();

                String url = "http://ip-api.com/json";

                JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                        new Response.Listener<JSONObject>() {

                            @Override
                            public void onResponse(JSONObject response) {

                                try {

                                    double lat = response.getDouble("lat");
                                    double lon = response.getDouble("lon");
                                    String city = response.getString("city");
                                    String region = response.getString("region");
                                    String country = response.getString("countryCode");

                                    loc = city + ", " + region + ", " + country;
                                    String server_url = "http://localhost:8081/currentLocation?lat=" + lat + "&long=" + lon;
                                    final String cityUrl = "http://localhost:8081/getCityImages?city=" + loc.replace(" ", "%20");
                                    JsonObjectRequest req = new JsonObjectRequest(Request.Method.GET, server_url, null,
                                            new Response.Listener<JSONObject>() {

                                                @SuppressLint("SetTextI18n")
                                                @Override
                                                public void onResponse(JSONObject response) {

                                                    try {

                                                        resp = response;
                                                        JSONObject currently = response.getJSONObject("currently");
                                                        JSONObject daily = response.getJSONObject("daily");
                                                        JSONArray data = daily.getJSONArray("data");

                                                        slideAdapter.lstOfLocations.add(0, loc);
                                                        slideAdapter.lstOfTemperature.add(0, (int)(currently.getDouble("temperature")) + "°F");
                                                        slideAdapter.lstOfSummary.add(0, currently.getString("summary"));

                                                        slideAdapter.lstOfHumidityVals.add(0, (int)((currently.getDouble("humidity")*100)) + "%");
                                                        slideAdapter.lstOfWindSpeedVals.add(0, Math.round(currently.getDouble("windSpeed")*100.0)/100.0 + " mph");
                                                        slideAdapter.lstOfVisibilityVals.add(0, Math.round(currently.getDouble("visibility")*100.0)/100.0 + " km");
                                                        slideAdapter.lstOfPressureVals.add(0, Math.round(currently.getDouble("pressure")*100.0)/100.0 + " mb");

                                                        for(int i = 0; i < 8; i++) {
                                                            JSONObject table = data.getJSONObject(i);
                                                            long t = table.getLong("time");

                                                            Date date = new Date(t*1000);
                                                            @SuppressLint("SimpleDateFormat") SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

                                                            int dayIcon;
                                                            switch(table.getString("icon")) {

                                                                case "clear-night":
                                                                    dayIcon = R.drawable.weather_night;
                                                                    break;

                                                                case "rain":
                                                                    dayIcon = R.drawable.weather_rainy;
                                                                    break;

                                                                case "sleet":
                                                                    dayIcon = R.drawable.weather_snowy_rainy;
                                                                    break;

                                                                case "snow":
                                                                    dayIcon = R.drawable.weather_snowy;
                                                                    break;

                                                                case "wind":
                                                                    dayIcon = R.drawable.weather_windy_variant;
                                                                    break;

                                                                case "fog":
                                                                    dayIcon = R.drawable.weather_fog;
                                                                    break;

                                                                case "cloudy":
                                                                    dayIcon = R.drawable.weather_cloudy;
                                                                    break;

                                                                case "partly-cloudy-night":
                                                                    dayIcon = R.drawable.weather_night_partly_cloudy;
                                                                    break;

                                                                case "partly-cloudy-day":
                                                                    dayIcon = R.drawable.weather_partly_cloudy;
                                                                    break;

                                                                default:
                                                                    dayIcon = R.drawable.weather_sunny;
                                                                    break;

                                                            }

                                                            switch(i) {

                                                                case 0:
                                                                    slideAdapter.lstOfDay1Dates.add(0, sdf.format(date) + "");
                                                                    slideAdapter.lstOfDay1Icons.add(0, dayIcon);
                                                                    slideAdapter.lstOfDay1TempLow.add(0, (int)(table.getDouble("temperatureLow")) + "");
                                                                    slideAdapter.lstOfDay1TempHigh.add(0, (int)(table.getDouble("temperatureHigh")) + "");
                                                                    break;

                                                                case 1:
                                                                    slideAdapter.lstOfDay2Dates.add(0, sdf.format(date) + "");
                                                                    slideAdapter.lstOfDay2Icons.add(0, dayIcon);
                                                                    slideAdapter.lstOfDay2TempLow.add(0, (int)(table.getDouble("temperatureLow")) + "");
                                                                    slideAdapter.lstOfDay2TempHigh.add(0, (int)(table.getDouble("temperatureHigh")) + "");
                                                                    break;

                                                                case 2:
                                                                    slideAdapter.lstOfDay3Dates.add(0, sdf.format(date) + "");
                                                                    slideAdapter.lstOfDay3Icons.add(0, dayIcon);
                                                                    slideAdapter.lstOfDay3TempLow.add(0, (int)(table.getDouble("temperatureLow")) + "");
                                                                    slideAdapter.lstOfDay3TempHigh.add(0, (int)(table.getDouble("temperatureHigh")) + "");
                                                                    break;

                                                                case 3:
                                                                    slideAdapter.lstOfDay4Dates.add(0, sdf.format(date) + "");
                                                                    slideAdapter.lstOfDay4Icons.add(0, dayIcon);
                                                                    slideAdapter.lstOfDay4TempLow.add(0, (int)(table.getDouble("temperatureLow")) + "");
                                                                    slideAdapter.lstOfDay4TempHigh.add(0, (int)(table.getDouble("temperatureHigh")) + "");
                                                                    break;

                                                                case 4:
                                                                    slideAdapter.lstOfDay5Dates.add(0, sdf.format(date) + "");
                                                                    slideAdapter.lstOfDay5Icons.add(0,dayIcon);
                                                                    slideAdapter.lstOfDay5TempLow.add(0, (int)(table.getDouble("temperatureLow")) + "");
                                                                    slideAdapter.lstOfDay5TempHigh.add(0, (int)(table.getDouble("temperatureHigh")) + "");
                                                                    break;

                                                                case 5:
                                                                    slideAdapter.lstOfDay6Dates.add(0, sdf.format(date) + "");
                                                                    slideAdapter.lstOfDay6Icons.add(0, dayIcon);
                                                                    slideAdapter.lstOfDay6TempLow.add(0, (int)(table.getDouble("temperatureLow")) + "");
                                                                    slideAdapter.lstOfDay6TempHigh.add(0, (int)(table.getDouble("temperatureHigh")) + "");
                                                                    break;

                                                                case 6:
                                                                    slideAdapter.lstOfDay7Dates.add(0, sdf.format(date) + "");
                                                                    slideAdapter.lstOfDay7Icons.add(0, dayIcon);
                                                                    slideAdapter.lstOfDay7TempLow.add(0, (int)(table.getDouble("temperatureLow")) + "");
                                                                    slideAdapter.lstOfDay7TempHigh.add(0, (int)(table.getDouble("temperatureHigh")) + "");
                                                                    break;

                                                                case 7:
                                                                    slideAdapter.lstOfDay8Dates.add(0, sdf.format(date) + "");
                                                                    slideAdapter.lstOfDay8Icons.add(0, dayIcon);
                                                                    slideAdapter.lstOfDay8TempLow.add(0, (int)(table.getDouble("temperatureLow")) + "");
                                                                    slideAdapter.lstOfDay8TempHigh.add(0, (int)(table.getDouble("temperatureHigh")) + "");
                                                                    break;

                                                            }
                                                        }

                                                        int icon;
                                                        switch(currently.getString("icon")) {

                                                            case "clear-night":
                                                                icon = R.drawable.weather_night;
                                                                break;

                                                            case "rain":
                                                                icon = R.drawable.weather_rainy;
                                                                break;

                                                            case "sleet":
                                                                icon = R.drawable.weather_snowy_rainy;
                                                                break;

                                                            case "snow":
                                                                icon = R.drawable.weather_snowy;
                                                                break;

                                                            case "wind":
                                                                icon = R.drawable.weather_windy_variant;
                                                                break;

                                                            case "fog":
                                                                icon = R.drawable.weather_fog;
                                                                break;

                                                            case "cloudy":
                                                                icon = R.drawable.weather_cloudy;
                                                                break;

                                                            case "partly-cloudy-night":
                                                                icon = R.drawable.weather_night_partly_cloudy;
                                                                break;

                                                            case "partly-cloudy-day":
                                                                icon = R.drawable.weather_partly_cloudy;
                                                                break;

                                                            default:
                                                                icon = R.drawable.weather_sunny;
                                                                break;
                                                        }

                                                        slideAdapter.lstOfIcons.add(0, icon);
                                                        slideAdapter.notifyDataSetChanged();

                                                        viewPager = findViewById(R.id.view_pager);
                                                        linearLayout = findViewById(R.id.linear_layout);

                                                        slideAdapter.notifyDataSetChanged();
                                                        viewPager.setAdapter(slideAdapter);
                                                        linearLayout.setupWithViewPager(viewPager, true);

                                                        JsonObjectRequest cityReq = new JsonObjectRequest(Request.Method.GET, cityUrl, null,
                                                                new Response.Listener<JSONObject>() {

                                                                    @SuppressLint("SetTextI18n")
                                                                    @Override
                                                                    public void onResponse(JSONObject response) {

                                                                        cityPhotosJson = response;

                                                                    }
                                                                }, new Response.ErrorListener() {
                                                            @Override
                                                            public void onErrorResponse(VolleyError error) {

                                                                error.printStackTrace();

                                                            }
                                                        });
                                                        queue.add(cityReq);

                                                    } catch (JSONException e) {

                                                        e.printStackTrace();

                                                    }
                                                }
                                            }, new Response.ErrorListener() {

                                        @Override
                                        public void onErrorResponse(VolleyError error) {

                                            error.printStackTrace();

                                        }
                                    });

                                    queue.add(req);

                                } catch (JSONException e){

                                    e.printStackTrace();

                                }
                            }
                        }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {

                        error.printStackTrace();

                    }
                });
                queue.add(request);
                addRemoveFavorites(address, res, flag);

                Intent intent = getIntent();
                res = intent.getStringExtra(SearchableActivity.CURRENTLY);
                flag = intent.getStringExtra(SearchableActivity.FLAG);
                address = intent.getStringExtra(SearchableActivity.LOCATION);

                editor = sharedPreferences.edit();
                return null;
            }

            protected void onPostExecute(Void result) {

                progressBar.setVisibility(View.INVISIBLE);
                progressBarIndicator.setVisibility(View.INVISIBLE);
                viewPagerLayout.setVisibility(View.VISIBLE);

            }

        }.execute();
    }

    private void makeApiCall(String text) {

        APICall.make(this, text, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {

                List<String> stringList = new ArrayList<>();
                try {

                    JSONObject responseObject = new JSONObject(response);
                    JSONArray array = responseObject.getJSONArray("predictions");
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject row = array.getJSONObject(i);
                        stringList.add(row.getString("description"));
                    }
                } catch (Exception e) {

                    e.printStackTrace();

                }
                // set data here and notify
                autoSuggestAdapter.setData(stringList);
                autoSuggestAdapter.notifyDataSetChanged();
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
            }

        });
    }

    public void removeFavorites(View view) {

        Toast toast = Toast.makeText(MainActivity.this, slideAdapter.lstOfLocations.get(viewPager.getCurrentItem()) + " was removed from favorites", Toast.LENGTH_SHORT);
        View toastView = toast.getView();
        toastView.setBackgroundColor(getResources().getColor(R.color.colorAccent));
        toastView.setPadding(30, 30,30,30);
        TextView textView = toast.getView().findViewById(android.R.id.message);
        textView.setTextColor(getResources().getColor(R.color.darkGray));
        toast.show();

        editor.remove(slideAdapter.lstOfLocations.get(viewPager.getCurrentItem()));
        editor.commit();

        slideAdapter.lstOfLocations.clear();
        slideAdapter.lstOfSummary.clear();
        slideAdapter.lstOfTemperature.clear();
        slideAdapter.lstOfIcons.clear();
        slideAdapter.lstOfHumidityVals.clear();
        slideAdapter.lstOfPressureVals.clear();
        slideAdapter.lstOfVisibilityVals.clear();
        slideAdapter.lstOfWindSpeedVals.clear();

        slideAdapter.lstOfDay1Dates.clear();
        slideAdapter.lstOfDay1Icons.clear();
        slideAdapter.lstOfDay1TempHigh.clear();
        slideAdapter.lstOfDay1TempLow.clear();

        slideAdapter.lstOfDay2Dates.clear();
        slideAdapter.lstOfDay2Icons.clear();
        slideAdapter.lstOfDay2TempHigh.clear();
        slideAdapter.lstOfDay2TempLow.clear();

        slideAdapter.lstOfDay3Dates.clear();
        slideAdapter.lstOfDay3Icons.clear();
        slideAdapter.lstOfDay3TempHigh.clear();
        slideAdapter.lstOfDay3TempLow.clear();

        slideAdapter.lstOfDay4Dates.clear();
        slideAdapter.lstOfDay4Icons.clear();
        slideAdapter.lstOfDay4TempHigh.clear();
        slideAdapter.lstOfDay4TempLow.clear();

        slideAdapter.lstOfDay5Dates.clear();
        slideAdapter.lstOfDay5Icons.clear();
        slideAdapter.lstOfDay5TempHigh.clear();
        slideAdapter.lstOfDay5TempLow.clear();

        slideAdapter.lstOfDay6Dates.clear();
        slideAdapter.lstOfDay6Icons.clear();
        slideAdapter.lstOfDay6TempHigh.clear();
        slideAdapter.lstOfDay6TempLow.clear();

        slideAdapter.lstOfDay7Dates.clear();
        slideAdapter.lstOfDay7Icons.clear();
        slideAdapter.lstOfDay7TempHigh.clear();
        slideAdapter.lstOfDay7TempLow.clear();

        slideAdapter.lstOfDay8Dates.clear();
        slideAdapter.lstOfDay8Icons.clear();
        slideAdapter.lstOfDay8TempHigh.clear();
        slideAdapter.lstOfDay8TempLow.clear();

        slideAdapter.notifyDataSetChanged();
        viewPagerLayout.setVisibility(View.INVISIBLE);
        doTasks();

    }

    public void openDetailsActivity(View view) {

        TextView t = view.findViewById(R.id.location);
        final String s = t.getText().toString();

        if(s.equals(loc)) {

            Intent intent = new Intent(this, Details.class);
            intent.putExtra(EXTRA_MESSAGE, resp + "");
            intent.putExtra(LOCATION, loc);
            intent.putExtra(CITY_JSON, cityPhotosJson + "");
            startActivity(intent);

        }
        else {

            final Intent intent = new Intent(this, Details.class);
            String url = "http://localhost:8081/weatherCard?address=" + s.replace(" ", "%20");
            final String cityUrl = "http://localhost:8081/getCityImages?city=" + s.replace(" ", "%20");
            JsonObjectRequest req = new JsonObjectRequest(Request.Method.GET, url, null,
                    new Response.Listener<JSONObject>() {

                        @SuppressLint("SetTextI18n")
                        @Override
                        public void onResponse(JSONObject response) {

                            r = response;
                            intent.putExtra(EXTRA_MESSAGE, r + "");
                            intent.putExtra(LOCATION, s);
                            intent.putExtra(CITY_JSON, c + "");
                            startActivity(intent);
                            JsonObjectRequest cityReq = new JsonObjectRequest(Request.Method.GET, cityUrl, null,
                                    new Response.Listener<JSONObject>() {

                                        @SuppressLint("SetTextI18n")
                                        @Override
                                        public void onResponse(JSONObject response) {

                                            c = response;
                                            intent.putExtra(EXTRA_MESSAGE, r + "");
                                            intent.putExtra(LOCATION, s);
                                            intent.putExtra(CITY_JSON, c + "");
                                            startActivity(intent);

                                        }
                                    }, new Response.ErrorListener() {

                                @Override
                                public void onErrorResponse(VolleyError error) {

                                    error.printStackTrace();

                                }
                            });
                            queue.add(cityReq);
                        }
                    }, new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError error) {

                    error.printStackTrace();

                }
            });
            queue.add(req);

        }
    }

    public void addRemoveFavorites(final String location, String response, String isFav) {

            for(String key: sharedPreferences.getAll().keySet()) {

                final String val = sharedPreferences.getString(key, "");

                String a = val.replace(" ", "%20");

                String url = "http://localhost:8081/weatherCard?address=" + a;
                JsonObjectRequest req = new JsonObjectRequest(Request.Method.GET, url, null,
                        new Response.Listener<JSONObject>() {

                            @SuppressLint("SetTextI18n")
                            @Override
                            public void onResponse(JSONObject response) {

                                try {

                                    resp = response;
                                    JSONObject currently = response.getJSONObject("currently");
                                    JSONObject daily = response.getJSONObject("daily");
                                    JSONArray data = daily.getJSONArray("data");

                                    slideAdapter.lstOfLocations.add(val);
                                    slideAdapter.lstOfTemperature.add((int) (currently.getDouble("temperature")) + "°F");
                                    slideAdapter.lstOfSummary.add(currently.getString("summary"));

                                    slideAdapter.lstOfHumidityVals.add((int) ((currently.getDouble("humidity") * 100)) + "%");
                                    slideAdapter.lstOfWindSpeedVals.add(Math.round(currently.getDouble("windSpeed") * 100.0) / 100.0 + " mph");
                                    slideAdapter.lstOfVisibilityVals.add(Math.round(currently.getDouble("visibility") * 100.0) / 100.0 + " km");
                                    slideAdapter.lstOfPressureVals.add(Math.round(currently.getDouble("pressure") * 100.0) / 100.0 + " mb");

                                    for (int i = 0; i < 8; i++) {

                                        JSONObject table = data.getJSONObject(i);
                                        long t = table.getLong("time");

                                        Date date = new Date(t * 1000);
                                        @SuppressLint("SimpleDateFormat") SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

                                        int dayIcon;
                                        switch (table.getString("icon")) {

                                            case "clear-night":
                                                dayIcon = R.drawable.weather_night;
                                                break;

                                            case "rain":
                                                dayIcon = R.drawable.weather_rainy;
                                                break;

                                            case "sleet":
                                                dayIcon = R.drawable.weather_snowy_rainy;
                                                break;

                                            case "snow":
                                                dayIcon = R.drawable.weather_snowy;
                                                break;

                                            case "wind":
                                                dayIcon = R.drawable.weather_windy_variant;
                                                break;

                                            case "fog":
                                                dayIcon = R.drawable.weather_fog;
                                                break;

                                            case "cloudy":
                                                dayIcon = R.drawable.weather_cloudy;
                                                break;

                                            case "partly-cloudy-night":
                                                dayIcon = R.drawable.weather_night_partly_cloudy;
                                                break;

                                            case "partly-cloudy-day":
                                                dayIcon = R.drawable.weather_partly_cloudy;
                                                break;

                                            default:
                                                dayIcon = R.drawable.weather_sunny;
                                                break;
                                        }

                                        switch (i) {

                                            case 0:
                                                slideAdapter.lstOfDay1Dates.add(sdf.format(date) + "");
                                                slideAdapter.lstOfDay1Icons.add(dayIcon);
                                                slideAdapter.lstOfDay1TempLow.add((int) (table.getDouble("temperatureLow")) + "");
                                                slideAdapter.lstOfDay1TempHigh.add((int) (table.getDouble("temperatureHigh")) + "");
                                                break;

                                            case 1:
                                                slideAdapter.lstOfDay2Dates.add(sdf.format(date) + "");
                                                slideAdapter.lstOfDay2Icons.add(dayIcon);
                                                slideAdapter.lstOfDay2TempLow.add((int) (table.getDouble("temperatureLow")) + "");
                                                slideAdapter.lstOfDay2TempHigh.add((int) (table.getDouble("temperatureHigh")) + "");
                                                break;

                                            case 2:
                                                slideAdapter.lstOfDay3Dates.add(sdf.format(date) + "");
                                                slideAdapter.lstOfDay3Icons.add(dayIcon);
                                                slideAdapter.lstOfDay3TempLow.add((int) (table.getDouble("temperatureLow")) + "");
                                                slideAdapter.lstOfDay3TempHigh.add((int) (table.getDouble("temperatureHigh")) + "");
                                                break;

                                            case 3:
                                                slideAdapter.lstOfDay4Dates.add(sdf.format(date) + "");
                                                slideAdapter.lstOfDay4Icons.add(dayIcon);
                                                slideAdapter.lstOfDay4TempLow.add((int) (table.getDouble("temperatureLow")) + "");
                                                slideAdapter.lstOfDay4TempHigh.add((int) (table.getDouble("temperatureHigh")) + "");
                                                break;

                                            case 4:
                                                slideAdapter.lstOfDay5Dates.add(sdf.format(date) + "");
                                                slideAdapter.lstOfDay5Icons.add(dayIcon);
                                                slideAdapter.lstOfDay5TempLow.add((int) (table.getDouble("temperatureLow")) + "");
                                                slideAdapter.lstOfDay5TempHigh.add((int) (table.getDouble("temperatureHigh")) + "");
                                                break;

                                            case 5:
                                                slideAdapter.lstOfDay6Dates.add(sdf.format(date) + "");
                                                slideAdapter.lstOfDay6Icons.add(dayIcon);
                                                slideAdapter.lstOfDay6TempLow.add((int) (table.getDouble("temperatureLow")) + "");
                                                slideAdapter.lstOfDay6TempHigh.add((int) (table.getDouble("temperatureHigh")) + "");
                                                break;

                                            case 6:
                                                slideAdapter.lstOfDay7Dates.add(sdf.format(date) + "");
                                                slideAdapter.lstOfDay7Icons.add(dayIcon);
                                                slideAdapter.lstOfDay7TempLow.add((int) (table.getDouble("temperatureLow")) + "");
                                                slideAdapter.lstOfDay7TempHigh.add((int) (table.getDouble("temperatureHigh")) + "");
                                                break;

                                            case 7:
                                                slideAdapter.lstOfDay8Dates.add(sdf.format(date) + "");
                                                slideAdapter.lstOfDay8Icons.add(dayIcon);
                                                slideAdapter.lstOfDay8TempLow.add((int) (table.getDouble("temperatureLow")) + "");
                                                slideAdapter.lstOfDay8TempHigh.add((int) (table.getDouble("temperatureHigh")) + "");
                                                break;
                                        }
                                    }

                                    int icon;
                                    switch (currently.getString("icon")) {

                                        case "clear-night":
                                            icon = R.drawable.weather_night;
                                            break;

                                        case "rain":
                                            icon = R.drawable.weather_rainy;
                                            break;

                                        case "sleet":
                                            icon = R.drawable.weather_snowy_rainy;
                                            break;

                                        case "snow":
                                            icon = R.drawable.weather_snowy;
                                            break;

                                        case "wind":
                                            icon = R.drawable.weather_windy_variant;
                                            break;

                                        case "fog":
                                            icon = R.drawable.weather_fog;
                                            break;

                                        case "cloudy":
                                            icon = R.drawable.weather_cloudy;
                                            break;

                                        case "partly-cloudy-night":
                                            icon = R.drawable.weather_night_partly_cloudy;
                                            break;

                                        case "partly-cloudy-day":
                                            icon = R.drawable.weather_partly_cloudy;
                                            break;

                                        default:
                                            icon = R.drawable.weather_sunny;
                                            break;
                                    }
                                    slideAdapter.lstOfIcons.add(icon);
                                    slideAdapter.notifyDataSetChanged();
                                } catch (JSONException e) {

                                    e.printStackTrace();

                                }
                            }
                        }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {

                        error.printStackTrace();

                    }
                });
                queue.add(req);
            }
    }

    @SuppressLint("RestrictedApi")
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);

        // Associate searchable configuration with the SearchView
        SearchManager searchManager =
                (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        searchView =
                (SearchView) MenuItemCompat.getActionView(menu.findItem(R.id.search));
        assert searchManager != null;
        searchView.setSearchableInfo(
                searchManager.getSearchableInfo(new ComponentName(this, SearchableActivity.class)));

        final SearchView.SearchAutoComplete searchAutoComplete = searchView.findViewById(androidx.appcompat.R.id.search_src_text);
        searchAutoComplete.setBackgroundColor(Color.parseColor("#222222"));
        searchAutoComplete.setTextColor(Color.WHITE);
        searchAutoComplete.setDropDownBackgroundResource(android.R.color.white);

        searchView.setOnQueryTextListener(this);
        //Setting up the adapter for AutoSuggest
        autoSuggestAdapter = new AutoSuggestAdapter(this,
                android.R.layout.simple_dropdown_item_1line);
        searchAutoComplete.setThreshold(2);
        searchAutoComplete.setAdapter(autoSuggestAdapter);
        searchAutoComplete.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {

                    @Override
                    public void onItemClick(AdapterView<?> parent, View view,
                                            int position, long id) {

                        searchAutoComplete.setText(autoSuggestAdapter.getObject(position));

                    }
                });

        searchAutoComplete.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int
                    count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {

                handler.removeMessages(TRIGGER_AUTO_COMPLETE);
                handler.sendEmptyMessageDelayed(TRIGGER_AUTO_COMPLETE,
                        AUTO_COMPLETE_DELAY);

            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        handler = new Handler(new Handler.Callback() {

            @Override
            public boolean handleMessage(Message msg) {

                if (msg.what == TRIGGER_AUTO_COMPLETE) {
                    if (!TextUtils.isEmpty(searchAutoComplete.getText())) {
                        makeApiCall(searchAutoComplete.getText().toString().replace(" ", "%20"));
                    }
                }
                return false;

            }
        });
        return super.onCreateOptionsMenu(menu);
    }

    @SuppressWarnings("RestrictedApi")
    @Override
    public boolean onQueryTextSubmit(String query) {

        Bundle appData = new Bundle();
        String s = dummy + "";
        appData.putString("dummy", s);
        appData.putBoolean(SearchableActivity.JARGON, true); // put extra data to Bundle
        searchView.setAppSearchData(appData); // pass the search context data

        return false; // we do not need to start the search activity manually, the system does it for us

    }

    @Override
    public boolean onQueryTextChange(String newText) {

        return false;

    }
}

